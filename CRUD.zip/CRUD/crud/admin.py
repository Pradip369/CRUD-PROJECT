from django.contrib import admin
from .models import Student


class StudentAdmin(admin.ModelAdmin):
      list_display = ["name","email","password"]

# @admin.register(Student,StudentAdmin)
admin.site.register(Student,StudentAdmin)