from django.shortcuts import render
from crud.forms import Studentregistration
from crud.models import Student
from django.http.response import HttpResponseRedirect

# Create your views here.
def add_show(request):
    if request.method == "POST":
        fm = Studentregistration(request.POST)
        if fm.is_valid():
            #   fm.save()
            nm = fm.cleaned_data['name']
            em = fm.cleaned_data['email']
            pw = fm.cleaned_data['password']
            st = Student.objects.create(name=nm,email=em,password=pw)
            st.save()
            return HttpResponseRedirect('/')
    else:
        fm = Studentregistration()
    fmd = Student.objects.all()
    return render(request,'add_show.html',{"fm":fm,"std":fmd})


def delete(request,pk):
    if request.method=="POST":
        pi = Student.objects.get(pk=pk)
        pi.delete()
    return HttpResponseRedirect('/')

def update(request,pk):
    if request.method=="POST":
        pi = Student.objects.get(pk=pk)
        fm = Studentregistration(request.POST,instance=pi)
        if fm.is_valid():
            fm.save()
        return HttpResponseRedirect('/')
    else:
        pi = Student.objects.get(pk=pk)
        fm = Studentregistration(instance=pi)
    return render(request,'update.html',{"pk":pk,"fm":fm})
