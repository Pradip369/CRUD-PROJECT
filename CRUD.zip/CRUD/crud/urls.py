from django.urls import path
from django.views.generic.base import RedirectView
from crud import views

urlpatterns = [
    path('home/',views.add_show),
    path('delete/<int:pk>/',views.delete,name="delete"),
    path('update/<int:pk>/',views.update,name="update"),
    path('',RedirectView.as_view(url='home/')),
]
